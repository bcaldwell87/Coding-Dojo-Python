from django.apps import AppConfig


class YourrwAppConfig(AppConfig):
    name = 'yourrw_app'
