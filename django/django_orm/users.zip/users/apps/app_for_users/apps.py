from django.apps import AppConfig


class AppForUsersConfig(AppConfig):
    name = 'app_for_users'
