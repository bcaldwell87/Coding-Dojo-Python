from django.apps import AppConfig


class DojosAndNinjasAppConfig(AppConfig):
    name = 'dojos_and_ninjas_app'
