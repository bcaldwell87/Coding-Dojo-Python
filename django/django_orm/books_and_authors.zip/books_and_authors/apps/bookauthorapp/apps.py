from django.apps import AppConfig


class BookauthorappConfig(AppConfig):
    name = 'bookauthorapp'
