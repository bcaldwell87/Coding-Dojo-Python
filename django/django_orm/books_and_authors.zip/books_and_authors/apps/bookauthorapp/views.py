from django.shortcuts import render
from .models import Book, Author

# Create your views here.
def index(request):
    return render(request, "bookauthorapp/index.html")

def new(request):
    return render(request, "bookauthorapp/new.html")