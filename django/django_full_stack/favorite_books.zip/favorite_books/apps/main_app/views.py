from django.shortcuts import render, HttpResponse, redirect
from .models import User, Book
from django.contrib import messages

def index(request):
    return render(request, "main_app/index.html")

def register(request):
    result = User.objects.validate(request.POST)
    if result[0] == False:
        for err in result[1]:
            messages.error(request, err)
        return redirect ('/')
    else:
        request.session['user_id'] = result[1].id
        request.session['user_first_name'] = result[1].first_name
        return redirect('/success')

def login(request):
    pass

def success(request):
    return render(request, "main_app/success.html")