from django.db import models
import re
import bcrypt
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
# Create your models here.
class UserManager(models.Manager):
    def validate(self, post_data):
        errors = []
        if len(post_data['first_name']) < 2:
            errors.append("First name is too short")

        if len(post_data['last_name']) < 2:
            errors.append("Last name is too short")

        if not EMAIL_REGEX.match(post_data['email']):
            errors.append("Email is not in the correct format")

        if len(post_data['password']) < 8:
            errors.append("Password is too short")

        if post_data['password'] != post_data['confirm_password']:
            errors.append("Passwords don't match")

        if len(errors) > 0:
            return (False, errors)

        else:
            new_user = self.create(
                first_name=post_data['first_name'],
                last_name=post_data['last_name'],
                email=post_data['email'],
                password=bcrypt.hashpw(post_data['password'].encode(), bcrypt.gensalt())
            )
            return (True, new_user)
            
class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=45)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class Book(models.Model):
    title = models.CharField(max_length=255)
    fans = models.ManyToManyField(User, related_name="favorite_books")
    uploader = models.ForeignKey(User, related_name="uploaded_books")
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title}"