from django.db import models
    
class Show(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    release_date = models.DateField()
    description = models.TextField()

    def __str__(self):
        return f"Title: {self.title} Description: {self.description}"