from django.apps import AppConfig


class BeltappConfig(AppConfig):
    name = 'beltapp'
